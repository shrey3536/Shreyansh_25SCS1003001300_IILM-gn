import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.linear_model import LinearRegression
from sklearn.cluster import KMeans
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import mean_squared_error, r2_score, accuracy_score
import pickle, os

base=os.path.dirname(__file__)
df=pd.read_csv(os.path.join(base,"student_dataset_100.csv"))

df["fees_outstanding"]=df["total_fees"]-df["fees_paid"]
df["pass_fail"]=(df["cgpa"]>=6).astype(int)
df["defaulter"]=(df["fees_paid"]<0.8*df["total_fees"]).astype(int)

out=f"{base}/outputs/plots"
os.makedirs(out,exist_ok=True)
plt.rcParams["figure.dpi"]=120

# Grade chart
plt.bar(df["grade"].value_counts().index, df["grade"].value_counts().values)
plt.title("Grade Distribution")
plt.savefig(f"{out}/grade.png"); plt.close()

# IQ chart
plt.hist(df["IQ"],bins=10); plt.title("IQ Histogram")
plt.savefig(f"{out}/iq.png"); plt.close()

# Scatter
plt.scatter(df["IQ"],df["cgpa"]); plt.title("CGPA vs IQ")
plt.savefig(f"{out}/scatter.png"); plt.close()

# Fees outstanding
top=df.sort_values("fees_outstanding",ascending=False).head(20)
plt.bar(top["student_id"],top["fees_outstanding"])
plt.xticks(rotation=45)
plt.title("Fees Outstanding Top 20")
plt.savefig(f"{out}/fees.png"); plt.close()

# Attendance
att=df.groupby("grade")["attendance"].mean()
plt.bar(att.index,att.values); plt.title("Attendance by Grade")
plt.savefig(f"{out}/attendance.png"); plt.close()

# Skills
skills=df["skills"].str.split(", ").explode().value_counts().head(20)
plt.bar(skills.index,skills.values); plt.xticks(rotation=45)
plt.title("Skills Frequency")
plt.savefig(f"{out}/skills.png"); plt.close()

# Heatmap
num=['age','IQ','total_fees','fees_paid','fees_outstanding','attendance','cgpa']
corr=df[num].corr()
plt.imshow(corr); plt.colorbar()
plt.xticks(range(len(num)),num,rotation=45)
plt.yticks(range(len(num)),num)
plt.title("Correlation Heatmap")
plt.savefig(f"{out}/heatmap.png"); plt.close()

# ML
cat=["gender","grade","city"]
num=["age","IQ","attendance","total_fees","fees_paid"]

ohe=OneHotEncoder(sparse_output=False, drop="first")
cat_enc=ohe.fit_transform(df[cat])
X=np.hstack([df[num].values,cat_enc])

# CGPA model
y=df["cgpa"].values
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=0.2,random_state=42)
model=RandomForestRegressor(n_estimators=200,random_state=42)
model.fit(Xtr,ytr)
pred=model.predict(Xte)
rmse=(mean_squared_error(yte,pred))**0.5
r2=r2_score(yte,pred)
pickle.dump(model,open(f"{base}/models/cgpa.pkl","wb"))

# Pass Fail
y=df["pass_fail"].values
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=0.2,random_state=42)
clf=RandomForestClassifier(n_estimators=200,random_state=42)
clf.fit(Xtr,ytr)
pickle.dump(clf,open(f"{base}/models/pass.pkl","wb"))

# Defaulter
y=df["defaulter"].values
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=0.2,random_state=42)
clf2=RandomForestClassifier(n_estimators=200,random_state=42)
clf2.fit(Xtr,ytr)
pickle.dump(clf2,open(f"{base}/models/def.pkl","wb"))

# Clustering
sc=StandardScaler()
Xc=sc.fit_transform(df[['IQ','attendance','cgpa','fees_outstanding']])
km=KMeans(n_clusters=3,random_state=42,n_init=10)
df['cluster']=km.fit_predict(Xc)
df.to_csv(f"{base}/student_dataset_100_with_labels.csv",index=False)
pickle.dump(km,open(f"{base}/models/kmeans.pkl","wb"))
pickle.dump(sc,open(f"{base}/models/scaler.pkl","wb"))

print("DONE.")
