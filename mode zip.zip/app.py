from flask import Flask, render_template, send_from_directory
import pandas as pd, os

app=Flask(__name__)
base=os.path.dirname(__file__)
df=pd.read_csv(os.path.join(base,"student_dataset_100.csv"))

@app.route("/")
def home():
    table=df.head(10).to_dict(orient="records")
    plots=os.listdir(os.path.join(base,"outputs","plots"))
    return render_template("index.html", table=table, plots=plots)

@app.route("/plot/<name>")
def plotimg(name):
    return send_from_directory(os.path.join(base,"outputs","plots"), name)

app.run(debug=True)
